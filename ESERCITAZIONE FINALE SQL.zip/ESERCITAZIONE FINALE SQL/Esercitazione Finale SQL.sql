CREATE DATABASE ToysGroup_EsercitazioneFinale;

USE ToysGroup_EsercitazioneFinale;

CREATE TABLE Product (
	ProductId INT PRIMARY KEY,
    ProductName VARCHAR (100),
    Category VARCHAR(100),
    UnitPrice DECIMAL (50, 2),
    Color VARCHAR (100),
    Age VARCHAR(100) );
    
    
   CREATE TABLE Region (
    RegionID INT PRIMARY KEY,
    RegionName VARCHAR(50),
    Country VARCHAR(50),
    ShippingMethod VARCHAR(50));
    
    
    CREATE TABLE Sales (
    SalesID INT PRIMARY KEY,
    SalesAmount DECIMAL (50, 2),
    TransactionDate DATE,
    Quantity INT,
    ProductId INT,
    RegionId INT,
	FOREIGN KEY (ProductId) REFERENCES Product(ProductId),
    FOREIGN KEY (RegionId) REFERENCES Region(RegionId)
);

INSERT INTO Product (ProductID, ProductName, Category, UnitPrice, Color, Age) VALUES
(1, 'Stuffed Bunny', 'Plush Toys', 12.99, 'White', '3+'),
(2, 'Wooden Train Set', 'Wooden Toys', 29.99, 'Multi', '3+'),
(3, 'Remote Control Car', 'Vehicles', 39.99, 'Red', '8+'),
(4, 'Dollhouse Kit', 'Dolls', 49.99, 'Pink', '5+'),
(5, 'Puzzle Game', 'Educational', 14.99, 'Multi', '6+'),
(6, 'Action Figure', 'Action Toys', 9.99, 'Blue', '4+'),
(7, 'Play Kitchen Set', 'Pretend Play', 34.99, 'Pink', '3+'),
(8, 'Building Blocks', 'Building', 19.99, 'Multi', '2+'),
(9, 'Art Supplies Kit', 'Creativity', 24.99, 'Multi', '5+'),
(10, 'Musical Instrument', 'Music', 49.99, 'Multi', '4+');

INSERT INTO Region (RegionID, RegionName, Country, ShippingMethod) VALUES
(201, 'Europe', 'Germany', 'Sea'),
(202, 'North America', 'USA', 'Air'),
(203, 'Europe', 'France', 'Sea'),
(204, 'Europe', 'Italy', 'Air'),
(205, 'Asia', 'Japan', 'Air'),
(206, 'Europe', 'Spain', 'Sea');

INSERT INTO Sales(SalesID, SalesAmount, TransactionDate, Quantity, ProductId, RegionId) VALUES 
(1, 38.97, '2023-05-15', 3, 1, 201),
(2, 119.96, '2023-05-16', 4, 2, 202),
(3, 79.98, '2023-05-17', 2, 3, 203),
(4, 99.96, '2023-05-18', 2, 4, 204),
(5, 44.97, '2023-05-19', 3, 5, 201),
(6, 39.96, '2023-05-20', 4, 6, 202),
(7, 104.97, '2023-05-21', 3, 7, 203);


-- Verificare che i campi definiti come PK siano univoci:

SELECT 'ProductID' AS PrimaryKey, COUNT(ProductID) AS Presence
FROM Product
GROUP BY ProductID
HAVING COUNT(ProductID) > 1;

SELECT 'RegionID' AS PrimaryKey, COUNT(RegionID) AS Presence
FROM Region
GROUP BY RegionID
HAVING COUNT(RegionID) > 1;

SELECT 'SalesID' AS PrimaryKey, COUNT(SalesID) AS Presence
FROM Sales
GROUP BY SalesID
HAVING COUNT(SalesID) > 1;


-- Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato (quantita e costo) totale per anno.

SELECT p.ProductId, p.ProductName, YEAR(s.TransactionDate) as SalesYear, SUM(s.Quantity * p.UnitPrice) as Revenue
FROM Sales s
INNER JOIN Product p ON s.ProductId = p.ProductId
GROUP BY p.ProductName, YEAR(s.TransactionDate), p.ProductId;


-- Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 

SELECT r.RegionId, r.Country, SUM(s.Quantity * p.UnitPrice) as Revenue, YEAR(s.TransactionDate) as SalesYear
FROM Sales s
INNER JOIN Region r ON s.RegionId = r.RegionId
INNER JOIN Product p ON s.ProductId = p.ProductId
GROUP BY SalesYear, r.RegionId
ORDER BY SalesYear DESC, Fatturato DESC;


-- Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?

SELECT p.Category, SUM(s.Quantity) as TotalQuantity
FROM Sales s
INNER JOIN Product p ON s.ProductId = p.ProductID
GROUP BY p.Category
ORDER BY TotalQuantity DESC
LIMIT 1;

-- Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 
-- Approccio 1

SELECT p.ProductId, p.ProductName
FROM Product p 
WHERE p.ProductId NOT IN
(SELECT s.ProductId FROM Sales s);

-- Approccio 2

SELECT p.ProductId, p.ProductName
FROM Product p 
LEFT JOIN Sales s ON p.ProductId = s.ProductId
WHERE s.ProductId IS NULL;

-- Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).

SELECT p.ProductName, MAX(s.TransactionDate) AS MostRecentSale
FROM Product p
INNER JOIN Sales s ON p.ProductId = s.ProductId
GROUP BY p.ProductName;